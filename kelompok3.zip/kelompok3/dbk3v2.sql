-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 10, 2021 at 02:50 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbk3v2`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_artikel`
--

CREATE TABLE `tbl_artikel` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) DEFAULT NULL,
  `isi` text DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `foto` varchar(100) DEFAULT NULL,
  `id_kategori` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_artikel`
--

INSERT INTO `tbl_artikel` (`id`, `judul`, `isi`, `tanggal`, `foto`, `id_kategori`) VALUES
(12, 'PELANTIKAN DAN PENGUKUHAN PMR SMK YAJ DEPOK', '<p><strong>PMR</strong> merupakan wadah penguatan karakter remaja dalam memupuk sikap kepedulian mereka kepada sesama dan lingkungan sekitar. Oleh karena itu, SMK YAJ DEPOK tetap memfasilitasi dengan sokongan morel maupun material, diantaranya yaitu dilaksanakan kegiatan rutin &ldquo;Masa Orientasi dan Pelantikan PMR.&rdquo;</p><p><em>Tugas anggota remaja PMI tercakup dalam Tri Bakti PMR :</em></p><p>1. Berbakti kepada masyarakat.</p><p>2. Mempertinggi keterampilan serta memelihara kebersihan dan kesehatan.</p><p>3. Mempererat persahabatan nasional dan Internasional.</p><p>Melalui kegiatan ekstra PMR ini, siswa yang memiliki hobi dan cita-cita menjadi petugas kesehatan serta berminat menjadi relawan dapat menyalurkan minat dan bakat mereka tersebut karena selain menerima materi, mereka juga bisa langsung praktik di sekolah.</p>', '2019-08-24', 'yaj4.jpeg', 10),
(13, 'Membangun Peserta Didik yang Berkarakter SMK YAJ Cilodong Depok', '<p>RADARDEPOK.COM – Memberikan kesan positif dan menyenangkan kepada peserta didik tentang lingkungan sekolah, menjadi tujuan utama dari kegiatan Masa Pengenalan Lingkungan Sekolah (MPLS) SMK YAJ Cilodong, yang dibuka kemarin (17/7). MPLS tahun ini, SMK YAJ mengambil tema Memupuk Semangat Solidaritas Dalam Membangun Kebersamaan Serta Rasa Tanggung Jawab di Lingkungan Sekolah.</p>\r\n<p>\r\nselengkap nya :\r\nhttp://radardepok.com/2019/07/membangun-peserta-didik-yang-berkarakter/</p>\r\n', '2020-01-10', 'yaj5.jpg', 3),
(14, 'Belajar Sehari Di Luar Kelas', '<p>Kamis, 15 Agustus 2019. SMK YAJ DEPOK melaksanakan kegiatan penyuluhan tentang Anemia yang bekerja sama dengan puskesmas di daerah depok.</p><p>Anemia pada remaja&nbsp;masih menjadi momok yang menakutkan di Indonesia. Khususnya anemia pada perempuan nusantara yang masih tinggi yaitu sebesar 22,7 persen.</p><p>Masa remaja merupakan masa di mana pertumbuhan&nbsp;terjadi dengan cepat. Pada masa ini, dibutuhan zat gizi&nbsp;untuk membantu kelancaran pertumbuhan.</p><p>Berbeda dengan kebutuhan laki-laki, setiap perempuan butuh asupan zat besi yang lebih tinggi. Tabel Angka Kecukupan Gizi (AKG) mengatakan bahwa kebutuhan zat besi remaja perempuan usia 13-29 tahun adalah 26 mg, angka ini jauh lebih tinggi bila dibandingkan laki-laki seusianya.</p><p>Hal itu dikarenakan perempuan tak hanya menggunakan zat besi untuk kebutuhan pertumbuhan. Zat besi berlebih ini hilang melalui darah yang keluar saat menstruasi setiap bulan.</p><p>Maka dari itu, perempuan remaja riskan mengalami kekurangan zat besi yang dapat berkembang menjadi anemia.</p>', '2020-01-10', '20210214-belajar-sehari-di-luar-kelas.jpeg', 3),
(18, 'sosialisasi anti rokok, narkoba, hiv dan kesehatan reproduksi di SMK YAJ', '<p>Selasa, (17/09/2019). BNN, KAPOLRES, PUSKESMAS, dan APARATUR KECAMATAN CILODONG melakukan Sosialisasi Anti Rokok, Narkoba, HIV, dan Kesehatan Reproduksi di SMK YAJ Depok.</p><p>1. Narkoba kadang kala juga disebut NAPZA (Narkotika, Psikotropika dan Zat Adiktif), yaitu zat/ kelompok senyawa bila dimasukkan ke dalam tubuh manusia, baik secara oral (melalui mulut), dihirup, maupun melalui pembuluh darah dengan menggunakan jarum suntik, akan dapat mengubah pikiran, suasana hati, atau perasaan, dan perilaku seseorang (UU No.22/1997).</p><p>2. Program HIV/AIDS didukung oleh 73 ,85% re sponden yang menyatakan sekolah telah membuat program tentang HIV/AIDS, namun sebanyak 23,08% responden tidak memprogramkannya.&nbsp;</p>', '2021-03-02', '20210302-sosialisasi-anti-rokok,-narkoba,-hiv-dan-kesehatan-reproduksi-di-smk-yaj.jpg', 10);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bukutamu`
--

CREATE TABLE `tbl_bukutamu` (
  `id` int(11) NOT NULL,
  `nama` varchar(80) DEFAULT NULL,
  `email` varchar(90) DEFAULT NULL,
  `isi` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ekskul`
--

CREATE TABLE `tbl_ekskul` (
  `id` int(11) NOT NULL,
  `nama_ekskul` varchar(50) DEFAULT NULL,
  `pembina` int(11) DEFAULT NULL,
  `isi` text NOT NULL,
  `foto` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_ekskul`
--

INSERT INTO `tbl_ekskul` (`id`, `nama_ekskul`, `pembina`, `isi`, `foto`) VALUES
(6, 'BTQ', 16, '<p>BTQ adalah Baca Tulis Qur\'an yang bertujuan untuk melihat kemampuan seseorang dalam membaca menulis al qur\'an</p>', 'btq.jpg'),
(7, 'Futsal', 16, '<p>Futsal adolah permainan bola nan dimainan dek duo tim, nan masiang-masiang ado limo urang. Tujuannyo adolah untuak mamasuakkan bola ka gawang lawan, jo caro mamanipulasi bola mamakai kaki. Salain limo pamain utamo, satiok tim juo diizinkan malatakkan pamain cadangan. Indak mirip jo pamainan sepak bola dalam ruangan nan lainnyo, lapangan futsal dibatehan dek garis, bukan net atau papan.</p>', 'futsal.gif'),
(8, 'Silat', 16, '<p>Pencak silat adalah suatu seni bela diri tradisional yang berasal dari Kepulauan Nusantara (Indonesia).[1] Seni bela diri ini secara luas dikenal di Indonesia, Malaysia, Brunei, dan Singapura, Filipina selatan, dan Thailand selatan sesuai dengan penyebaran berbagai suku bangsa Nusantara (Indonesia).[2] Unsur-unsur untuk membela diri dengan seni bela diri, yaitu dengan menggunakan pukulan dan tendangan. Pencak silat merupaka bela diri yang banyak diminati oleh banyak orang terutama masyarakat Indonesia.[1]</p>', 'silat.jpg'),
(9, 'Pramuka', 16, '<p>Pramuka adalah singkatan dari Praja Muda Karana dan merupakan organisasi atau gerakan kepanduan. Pramuka adalah sebuah organisasi yang merupakan wadah proses pendidikan kepramukaan yang dilaksanakan di Indonesia. Dalam dunia internasional, Pramuka disebut dengan istilah \"Kepanduan\" (Boy Scout). Gerakan Pramuka memiliki kode Kode Kehormatan Pramuka, sebagaimana yang tertuang dalam Anggaran Dasar Pramuka, Gerakan Pramuka memiliki Kode Kehormatan yang terdiri atas janji yang disebut Satya dan Ketentuan Moral yang disebut Darma Kode Kehormatan Pramuka disesuaikan dengan golongan usia dan perkembangan rohani dan jasmaninya, yaitu: Kode Kehormatan Pramuka Siaga terdiri atas Dwisatya dan Dwidarma. Kode Kehormatan Pramuka Penggalang terdiri atas Trisatya Pramuka Penggalang dan Dasadarma. Kode Kehormatan Pramuka Penegak dan Pandega terdiri atas Trisatya Pramuka Penegak dan Pramuka Pandega dan Dasadarma. Kode Kehormatan Pramuka Dewasa terdiri atas Trisatya Anggota Dewasa dan Dasadarma.</p>', 'pramuka1.jpg'),
(10, 'Paskribra', 20, '', ''),
(11, 'PMR', 16, '', ''),
(12, 'Band', 16, '', ''),
(13, 'Tae Kwon Do', 16, '', ''),
(14, 'Sepak Bola', 16, '', ''),
(15, 'Karate', 16, '', ''),
(16, 'Tahfidz ', 16, '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_galeri`
--

CREATE TABLE `tbl_galeri` (
  `id` int(11) NOT NULL,
  `nama_file` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `tbl_galeri`
--

INSERT INTO `tbl_galeri` (`id`, `nama_file`) VALUES
(2, '8.jpg'),
(3, '2.jpg'),
(4, '3.jpg'),
(5, '4.jpg'),
(6, '5.jpg'),
(7, '6.jpg'),
(8, '7.jpg'),
(9, '9.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_guru`
--

CREATE TABLE `tbl_guru` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `nip` int(10) DEFAULT NULL,
  `jenis_kelamin` enum('L','P') DEFAULT NULL,
  `no_hp` varchar(12) DEFAULT NULL,
  `tempat_lahir` varchar(50) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `mata_pelajaran` varchar(50) DEFAULT NULL,
  `alamat` varchar(100) DEFAULT NULL,
  `foto` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_guru`
--

INSERT INTO `tbl_guru` (`id`, `nama`, `nip`, `jenis_kelamin`, `no_hp`, `tempat_lahir`, `tanggal_lahir`, `mata_pelajaran`, `alamat`, `foto`) VALUES
(16, 'Idham Kholid, S.Ag, S.E.', 121212, 'L', '122121212', '1212', '2021-02-16', 'Kepala Sekolah', 'Kp. Sawah Jatimulya Cilodong Depok', '.jpg'),
(17, 'Ayu Budi Lestari, S.Kom.', 23232, 'P', '-', 'planet bumi', '2077-09-06', 'Rekayasa Perangkat Lunak', 'Jl. H. Abdul Gani 2 RT. 007/004 Komplek Pal Kostrad Cilodong Kota Depok 16413', '.png'),
(20, 'Yusuf Zamzami Ation', 1010, 'L', '11', '11', '2077-06-17', 'Pendidikan Agama Islam', 'Gg. Mesjid Abdurrahman Bin Auf RT. 03 RW. 06 Kelurahan Tengah Cibinong Bogor', 'yusuf-zamzami-ation.png'),
(21, 'Lukmanul Hakim, S.Kom.', 1010101, 'L', '1', 's', '2077-12-17', 'Teknik Komputer dan Jaringan', ' Jl. Nawih Sirih RT. 03/02 Kel. Jatimulya Kec. Cilodong Kota Depok 16413', 'lukmanul-hakim,-s.kom..png'),
(22, 'Hilda Rahmawati, S.Kom', 21212, 'P', '002121212182', '-', '2021-03-03', 'Pemograman ', 'Kp. Palsigunung RT. 03/03 No. 18 Cimanggis Depok 16951', 'hilda-rahmawati,-s.kom.png'),
(23, 'Abdul Salim', 2147483647, 'L', '-', '-', '2021-03-11', 'Simulasi Digital', 'Kp. Pajeleran RT. 01 RW. 08 Kelurahan Sukahati Kecamatan Cibinong Kabupaten Bogor', 'abdul-salim.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jurusan`
--

CREATE TABLE `tbl_jurusan` (
  `id` int(11) NOT NULL,
  `nama_jurusan` varchar(50) DEFAULT NULL,
  `ka_prodi` int(11) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  `foto` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_jurusan`
--

INSERT INTO `tbl_jurusan` (`id`, `nama_jurusan`, `ka_prodi`, `deskripsi`, `foto`) VALUES
(6, 'Teknik Komputer Jaringan', 21, '<p>Teknik Komputer dan Jaringan merupakan ilmu berbasis Teknologi Informasi dan Komunikasi terkait kemampuan algoritma, dan pemrograman komputer, perakitan komputer, perakitan jaringan komputer, dan pengoperasian perangkat lunak, dan internet. Teknik komputer, dan jaringan juga membutuhkan pemahaman di bidang teknik listrik, dan ilmu komputer sehingga mampu mengembangkan, dan mengintegrasikan perangkat lunak, dan perangkat keras.</p>', 'tkj1.png'),
(13, 'Rekayasa Perangkat Lunak', 22, '<p>Rekayasa perangkat lunak adalah satu bidang profesi yang mendalami cara-cara pengembangan perangkat lunak termasuk pembuatan, pemeliharaan, manajemen organisasi pengembanganan perangkat lunak dan manajemen kualitas. Rekayasa perangkat lunak sebagai penerapan suatu pendekatan yang sistematis, disiplin dan terkuantifikasi atas pengembangan, penggunaan dan pemeliharaan perangkat lunak, serta studi atas pendekatan-pendekatan ini, yaitu penerapan pendekatan engineering atas perangkat lunak (EEE Computer Society). Jadi Rekayasa Perangkat Lunak adalah pengubahan perangkat lunak itu sendiri guna mengembangkan, memelihara, dan membangun kembali dengan menggunakan prinsip reakayasa untuk menghasilkan perangkat lunak yang dapat bekerja lebih efisien dan efektif untuk pengguna.</p>\r\n\r\n', 'RPL1.jpg'),
(14, 'Akuntansi dan Keuangan Lembaga', 16, '<p>Akuntansi adalah segala proses yang berhubungan dengan transaksi keuangan mulai dari pencatatan, mengklasifikasi jenis transaksi, meringkasnya, mengolah dan menjadikan sebuah data, tujuannya adalah untuk menjadikan sebuah laporan keuangan yang akurat</p>', 'akl1.jpg'),
(15, 'Otomatisasi dan Tata Kelola Perkantoran', 16, '<p>Otomatisasi dan Tata Kelola Perkantoran adalah sebuah jurusan yang sangat berhubungan denga surat menyurat dan komunikasi. Hampir setiap hari kalian akan dihadapkan dengan pelajaran surat menyurat dan komunikasi.</p>\r\n<p>\r\nJika kalian di SMP sudah menyukai pelajaran Bahasa Indonesia dan Bahasa Inggris, saya sarankan jangan ragu lagi untuk memilih Administrasi Perkantoran.</p>', 'otp.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kategori_artikel`
--

CREATE TABLE `tbl_kategori_artikel` (
  `id` int(11) NOT NULL,
  `nama_kategori` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_kategori_artikel`
--

INSERT INTO `tbl_kategori_artikel` (`id`, `nama_kategori`) VALUES
(3, 'Kegiatan Sekolah'),
(10, 'Event');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kontak`
--

CREATE TABLE `tbl_kontak` (
  `id_kontak` int(11) NOT NULL,
  `kontak` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_kontak`
--

INSERT INTO `tbl_kontak` (`id_kontak`, `kontak`) VALUES
(1, '<i class=\"fa fa-phone\"></i> <strong> 021-87900425</strong>\r\n<p><i class=\"fa fa-envelope\"></i> info@smkyajdepok.sch.id</p>');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kurikulum`
--

CREATE TABLE `tbl_kurikulum` (
  `id_kurikulum` int(11) NOT NULL,
  `kurikulum` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_kurikulum`
--

INSERT INTO `tbl_kurikulum` (`id_kurikulum`, `kurikulum`) VALUES
(1, '<p>Kurikulum 2013 (K-13) adalah kurikulum yang berlaku dalam Sistem Pendidikan Indonesia. Kurikulum ini merupakan kurikulum tetap diterapkan oleh pemerintah untuk menggantikan Kurikulum-2006 (yang sering disebut sebagai Kurikulum Tingkat Satuan Pendidikan) yang telah berlaku selama kurang lebih 6 tahun. Kurikulum 2013 masuk dalam masa percobaanya pada tahun 2013 dengan menjadikan beberapa sekolah menjadi sekolah rintisan.\r\n</p>\r\n<p>\r\nLogo buku versi Kurikulum 2013.\r\nPada tahun ajaran 2013/2014, tepatnya sekitar pertengahan tahun 2013, Kurikulum 2013 diimpelementasikan secara terbatas pada sekolah perintis, yakni pada kelas I dan IV untuk tingkat Sekolah Dasar, kelas VII untuk SMP, dan kelas X untuk jenjang SMA/SMK, sedangkan pada tahun 2014, Kurikulum 2013 sudah diterapkan di Kelas I, II, IV, dan V sedangkan untuk SMP Kelas VII dan VIII dan SMA Kelas X dan XI. Jumlah sekolah yang menjadi sekolah perintis adalah sebanyak 6.326 sekolah tersebar di seluruh provinsi di Indonesia.[1]\r\n</p>\r\n<p>\r\nKurikulum 2013 memiliki empat aspek penilaian, yaitu aspek pengetahuan, aspek keterampilan, aspek sikap, dan perilaku. Di dalam Kurikulum 2013, terutama di dalam materi pembelajaran terdapat materi yang dirampingkan dan materi yang ditambahkan. Materi yang dirampingkan terlihat ada di materi Bahasa Indonesia, IPS, PPKn, dsb., sedangkan materi yang ditambahkan adalah materi Matematika.[butuh rujukan]\r\n</p>\r\n<p>\r\nMateri pelajaran tersebut (terutama Matematika dan Ilmu Pengetahuan Alam) disesuaikan dengan materi pembelajaran standar Internasional (seperti PISA dan TIMSS) sehingga pemerintah berharap dapat menyeimbangkan pendidikan di dalam negeri dengan pendidikan di luar negeri.[2]\r\n</p>\r\n<p>\r\nBerdasarkan Peraturan Menteri Pendidikan dan Kebudayaan, Anies Baswedan, nomor 60 tahun 2014 tanggal 11 Desember 2014, pelaksanaan Kurikulum 2013 dihentikan dan sekolah-sekolah untuk sementara kembali menggunakan Kurikulum Tingkat Satuan Pendidikan, kecuali bagi satuan pendidikan dasar dan menengah yang sudah melaksanakannya selama 3 (tiga) semester, satuan pendidikan usia dini, dan satuan pendidikan khusus.[3][4] Penghentian tersebut bersifat sementara, paling lama sampai tahun pelajaran 2019/2020.</p>');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pengguna`
--

CREATE TABLE `tbl_pengguna` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) DEFAULT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `foto` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_pengguna`
--

INSERT INTO `tbl_pengguna` (`id`, `nama`, `username`, `password`, `foto`) VALUES
(3, 'Administrator', 'admin', '$2y$10$9uAKnax9/7HoMVtMFWDUEe6GhtWdq5SIn75AWwHnYboKctXCfybVG', 'administrator.jpg'),
(4, 'user', 'user', '$2y$10$TGntwPeJKY57SbXhtfDPqeYpdLnSYoc58N238rJhFO2cytiQoGWze', 'user.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ppdb`
--

CREATE TABLE `tbl_ppdb` (
  `id_ppdb` int(11) NOT NULL,
  `ppdb` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_ppdb`
--

INSERT INTO `tbl_ppdb` (`id_ppdb`, `ppdb`) VALUES
(1, 'ppdb1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_prestasi`
--

CREATE TABLE `tbl_prestasi` (
  `id_prestasi` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `isi` text NOT NULL,
  `tanggal` date DEFAULT NULL,
  `foto` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_prestasi`
--

INSERT INTO `tbl_prestasi` (`id_prestasi`, `judul`, `isi`, `tanggal`, `foto`) VALUES
(1, 'Juara 1 Lomba Pidato Tingkat SMK Se-Kota Depok', '<p>Firman Maulana siswa SMK YAJ Cilodong menjadi Juara 1 lomba pidato, saat pentas seni Pendidikan Agama Islam (PAI) tingkat SMK se-Kota Depok</p>', '2020-11-10', 'prestasi1.png');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sejarah`
--

CREATE TABLE `tbl_sejarah` (
  `id_sejarah` int(11) NOT NULL,
  `sejarah` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_sejarah`
--

INSERT INTO `tbl_sejarah` (`id_sejarah`, `sejarah`) VALUES
(1, '<p>Eksistensi SMK YAJ di bawah naungan Yayasan Arridho Jatimulya yang beralamat di Jl. Arridho No. 166 Kp. Sawah RT. 01/04 Kel. Jatimulya Kec. Cilodong Kota Depok Telp. (021) 87900425, Email : smkyajdepok@yahoo.co.id.</p>\r\n<p>SMK YAJ lahir dari hasil perjuangan dan kerja keras putera asli Jatimulya yang konsen ingin membangun dan memajukan wilayahnya. SMK YAJ perlahan terus berkembang dengan diawalinya Tahun Pelajaran 2007/2008 yang juga awal lahirnya SMK YAJ. Pada tahun tersebut mendapatkan perhatian yang baik dari Dinas Pendidikan Kota Depok dalam bentuk dikeluarkannya izin operasional, sehingga secara legalitas SMK YAJ siap untuk mengelola pendidikan yang dapat dipertanggung-jawabkan. Ditambah lagi pada awal lahir </p>\r\n<p>Banyak bantuan-bantuan baik dari Pemerintah, donatur-donatur yang siap membantu meringankan biaya pendidikan bagi pserta didik yang  tidak dan kurang mampu, sehingga pada akhirnya SMK YAJ melahirkan komunitas dewan penyantun.</p>\r\n<p>Allhamdulilah, tiap tahun SMK YAJ Depok terus mengalami kenaikan dan perubahan dalam pembangunannya, dari mulai 2 rombongan belajar (rombel) pada mulai dibukanya SMK YAJ, sekarang menjadi 13 rombel dan  fasilitas-fasilitas penunjang seperti Laboratorium komputer untuk masing-masing Kompetensi Keahlian, Bank Mini yang dikelola oleh Kompetensi Keahlian Akuntansi dan Aministrasi Perkantoran, Perpustakaan yang tentram dan sejuk dengan fasilitas AC, BP/BK, Kantin, Koperasi Mini serta fasilitas WIFI Gratis bagi seluruh peserta didik SMK YAJ.\r\n</p><p>Adapun Jenjang Pendidikan yang dikelola oleh Yayasan Arridho Jatimulya itu sendiri adalah meliputi antara lain :</p>\r\n\r\n<p>1.	PAUD Delima YAJ</p>\r\n<p>2.	TKIT Mutiara Hikmah YAJ</p>\r\n<p>3.	SDIT Uswatun Hasanah</p>\r\n<p>4.	SMPIT Darul Barokah</p>\r\n<p>5.	SMK YAJ</p>\r\n\r\n<p>Dengan Kompetensi Keahlian sebagai berikut :</p>\r\n<p>a.	Teknik Komputer dan Jaringan</p>\r\n<p>b.	Rekayasa Perangkat Lunak</p>\r\n<p>c.	Akuntansi dan Keuangan Lembaga\r\n<p>d.	Otomatisasi dan Tata Kelola Perkantoran</p>\r\n<p>Untuk meningkatkan SDM, maka SMK YAJ Depok telah menerapkan kurikulum 2013 Revisi sedangkan untuk SMK YAJ sendiri juga menerapkan sekolah berbasis IT dengan Ujian-ujian atau Ulangan berbasis komputer, dengan demikian SMK ini adalah alternatif sekolah yang berkompeten bagi orang tua yang ingin menyekolakan anaknya.\r\nSekolah mengadakan pemeliharaan dan pengadaan terhadap sarana dan prasarana diantaranya adalah :</p>\r\n<p>1.	Gedung 3 lantai</p>\r\n<p>2.	Perpustakaan</p>\r\n<p>3.	Laboratorium Komputer</p>\r\n<p>4.	Laboratorium Perakitan PC</p>\r\n<p>5.	Laboratorium Instalasi Jaringan</p>\r\n<p>6.	Laboratorium Perkantoran</p>\r\n<p>7.	Sarana Olaharga</p>\r\n<p>8.	Sarana Ibadah</p>\r\n<p>Kurikulum yang digunakan adalah perpaduan antara kurikulum Kementrian Pendidikan Nasional. Disamping itu juga tidak meninggalkan  kurikulum tambahan yang disesuaikan dengan kebutuhan  industri di luar, agar dapat terciptanya siswa yang terampil dalam bidangnya.</p>\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_tentang_website`
--

CREATE TABLE `tbl_tentang_website` (
  `id` int(11) NOT NULL,
  `tentang_website` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_tentang_website`
--

INSERT INTO `tbl_tentang_website` (`id`, `tentang_website`) VALUES
(1, '<p>Tentang Website SMK YAJ Depok&nbsp;dan pembaharuan Versinya.</p><p>Website SMK YAJ Depok sebagai media yang dikelola oleh sekolah dan berada di Wilayah Negara Kesatuan Republik Indonesia tentunya Taat dan Patuh sepenuhnya terhadap Hukum dan Perundang Undangan yang berlaku di wilayah Negara Kesatuan Republik Indonesia. Dan mentaati Undang Undang Nomor 19 Tahun 2016 tentang ITE seperti yang tercantum pada tautan berikut&nbsp;UU Nomor 19 Tahun 2016</p><p>Website SMK YAJ Depok sebelumnya berada di smkyajdepok.sch.id dan karena suatu hal maka mulai tahun 2018 diluncurkan website dengan alamat baru yaitu www.smkyajdepok.sch.id. Mulai dikerjakan pada akhir Maret 2018 dan akhirnya bisa online pada tanggal 27 Maret 2018.</p>');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_visi_misi`
--

CREATE TABLE `tbl_visi_misi` (
  `id` int(11) NOT NULL,
  `visi_misi` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_visi_misi`
--

INSERT INTO `tbl_visi_misi` (`id`, `visi_misi`) VALUES
(1, '<p><strong>Visi&nbsp;</strong><strong>SMK YAJ DEPOK</strong></p><ol><li>Menjadikan SMK YAJ sebagai Sekolah Menengah Kejuruan yang mencetak siswa terampil, unggul dan mandiri pada Tahun 2022</li></ol><p><strong>Misi SMK YAJ DEPOK</strong></p><ol><li>Melahirkan lulusan yang berkualitas dalam penguasaan ilmu pengetahuan dan teknologi yang berlandaskan pada iman dan taqwa serta berakhlakul karimah.</li><li>Melahirkan lulusan yang dapat menciptakan peluang usaha dan mampu bersaing dalam dunia kerja.</li><li>Meningkatkan mutu dan profesionalisme pendidikan.</li></ol><p><strong>Motto SMK YAJ DEPOK</strong></p><ul><li><em>Kami datang untuk belajar dan mengikuti peraturan yang ada</em></li></ul>');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_artikel`
--
ALTER TABLE `tbl_artikel`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `foto` (`foto`),
  ADD KEY `id_kategori` (`id_kategori`);

--
-- Indexes for table `tbl_bukutamu`
--
ALTER TABLE `tbl_bukutamu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_ekskul`
--
ALTER TABLE `tbl_ekskul`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pembina` (`pembina`);

--
-- Indexes for table `tbl_galeri`
--
ALTER TABLE `tbl_galeri`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_guru`
--
ALTER TABLE `tbl_guru`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_jurusan`
--
ALTER TABLE `tbl_jurusan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tbl_jurusan_ibfk_1` (`ka_prodi`);

--
-- Indexes for table `tbl_kategori_artikel`
--
ALTER TABLE `tbl_kategori_artikel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_kontak`
--
ALTER TABLE `tbl_kontak`
  ADD PRIMARY KEY (`id_kontak`);

--
-- Indexes for table `tbl_kurikulum`
--
ALTER TABLE `tbl_kurikulum`
  ADD PRIMARY KEY (`id_kurikulum`);

--
-- Indexes for table `tbl_pengguna`
--
ALTER TABLE `tbl_pengguna`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_ppdb`
--
ALTER TABLE `tbl_ppdb`
  ADD PRIMARY KEY (`id_ppdb`);

--
-- Indexes for table `tbl_prestasi`
--
ALTER TABLE `tbl_prestasi`
  ADD PRIMARY KEY (`id_prestasi`);

--
-- Indexes for table `tbl_sejarah`
--
ALTER TABLE `tbl_sejarah`
  ADD PRIMARY KEY (`id_sejarah`);

--
-- Indexes for table `tbl_tentang_website`
--
ALTER TABLE `tbl_tentang_website`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_visi_misi`
--
ALTER TABLE `tbl_visi_misi`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_artikel`
--
ALTER TABLE `tbl_artikel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tbl_bukutamu`
--
ALTER TABLE `tbl_bukutamu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_ekskul`
--
ALTER TABLE `tbl_ekskul`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `tbl_galeri`
--
ALTER TABLE `tbl_galeri`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tbl_guru`
--
ALTER TABLE `tbl_guru`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `tbl_jurusan`
--
ALTER TABLE `tbl_jurusan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tbl_kategori_artikel`
--
ALTER TABLE `tbl_kategori_artikel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tbl_kontak`
--
ALTER TABLE `tbl_kontak`
  MODIFY `id_kontak` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_kurikulum`
--
ALTER TABLE `tbl_kurikulum`
  MODIFY `id_kurikulum` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_pengguna`
--
ALTER TABLE `tbl_pengguna`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_ppdb`
--
ALTER TABLE `tbl_ppdb`
  MODIFY `id_ppdb` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_prestasi`
--
ALTER TABLE `tbl_prestasi`
  MODIFY `id_prestasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_sejarah`
--
ALTER TABLE `tbl_sejarah`
  MODIFY `id_sejarah` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_tentang_website`
--
ALTER TABLE `tbl_tentang_website`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_visi_misi`
--
ALTER TABLE `tbl_visi_misi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbl_artikel`
--
ALTER TABLE `tbl_artikel`
  ADD CONSTRAINT `tbl_artikel_ibfk_1` FOREIGN KEY (`id_kategori`) REFERENCES `tbl_kategori_artikel` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `tbl_ekskul`
--
ALTER TABLE `tbl_ekskul`
  ADD CONSTRAINT `tbl_ekskul_ibfk_1` FOREIGN KEY (`pembina`) REFERENCES `tbl_guru` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `tbl_jurusan`
--
ALTER TABLE `tbl_jurusan`
  ADD CONSTRAINT `tbl_jurusan_ibfk_1` FOREIGN KEY (`ka_prodi`) REFERENCES `tbl_guru` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
