<?php 

require_once 'koneksi.php';
if (!isset($_GET['id']) || $_GET['id'] == '') header('Location: index.php');
$id = $_GET['id'];
$query = mysqli_query($koneksi, "SELECT * FROM tbl_ekskul WHERE id = $id");
$ekskul = mysqli_fetch_assoc($query);
$aktif = 'ekskul';
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Detail Eskul - SMK YAJ DEPOK</title>
	<link rel="stylesheet" href="resources/fonts/stylesheet.css">
	<link rel="stylesheet" href="resources/css/bootstrap.min.css">
	<link rel="stylesheet" href="resources/css/style.css">
	<link rel="icon" href="resources/images/logobc.png">
</head>
<body>
	<div class="container bg-light">
		<!-- top bar -->
		<?php require_once 'top-bar.php'?>
		<!-- nav bar -->
		<?php require_once 'navbar.php'; ?>

		<!-- content -->
		<div class="row p-3">
			<div class="col-md-8">
				<div class="title mb-3">
					<?= $ekskul['nama_ekskul'] ?> 
				</div>
				<div class="artikel">
					<img src="images/eskul/<?= $ekskul['foto'] ?>" alt="" width="100%" class="float-left mb-3 img-thumbnail">
					<?= $ekskul['isi'] ?>
				</div>
			</div>
			<?php require_once 'sidebar.php'; ?>
		</div>
		<?php require 'footer.php';?>