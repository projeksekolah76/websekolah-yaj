<?php 

require_once 'koneksi.php';

$query = mysqli_query($koneksi, "SELECT * FROM tbl_kontak ");
$kontak = mysqli_fetch_assoc($query);
$aktif = 'kontak'; 
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>kontak - SMK YAJ Depok</title>
	<link rel="stylesheet" href="resources/fonts/stylesheet.css">
	<link rel="stylesheet" href="resources/css/bootstrap.min.css">
	<link rel="stylesheet" href="resources/css/style.css">
	<link rel="stylesheet" href="fontawesome/css/all.min.css">
	<link rel="icon" href="resources/images/logobc.png">
</head>
<body>
<script src="http://maps.googleapis.com/maps/api/js"></script>
<script>
function initialize() {
  var propertiPeta = {
    center:new google.maps.LatLng(-6.4464194,106.8280174),
    zoom:10,
    mapTypeId:google.maps.MapTypeId.ROADMAP
  };
  
  var peta = new google.maps.Map(document.getElementById("googleMap"), propertiPeta);
  
  // membuat Marker
  var marker=new google.maps.Marker({
      position: new google.maps.LatLng(-6.4464194,106.8280174),
      map: peta,
      animation: google.maps.Animation.BOUNCE
  });

}

// event jendela di-load  
google.maps.event.addDomListener(window, 'load', initialize);
</script>
	<div class="container bg-light">
		<!-- top bar -->
		<?php require_once 'top-bar.php'?>
		<!-- nav bar -->
		<?php require_once 'navbar.php'; ?>

		<!-- content -->
		<div class="row p-3">
			<div class="col-md-8">
				<div class="title mb-3">
					Kontak SMK YAJ Depok
				</div>
				<div class="artikel">
					
				<link href='https://maxcdn.bootstrapcdn.com/font-awesome/4.4.0/css/font-awesome.min.css' rel='stylesheet'/>
					<style>
					.social-profiles-widget{width:100%;height:auto;padding:0}
					.social-profiles-widget ul {list-style: none;float: RIGHT;padding: 0;}
					.social-profiles-widget ul li{list-style:none;margin:0;display:inline}
					.social-profile .fa {width:50px;height:45px;color:rgba(255,255,255,0.8);text-align:center;line-height: 45px;
					font-size: 2em;-webkit-transition: all 0.5s ease-in-out;-moz-transition: all 0.5s ease-in-out;-ms-transition: all 0.5s ease-in-out;-o-transition: all 0.5s ease-in-out;transition: all 0.5s ease-in-out;margin-right: 5px;}
					.social-profile .fa-facebook{background:#3b5998}
					.social-profile .fa-twitter{background:#55acee}
					.social-profile .fa-youtube{background:#cc181e}
					.social-profile .fa-instagram{background:#9c694c}
					.social-profile .fa-google-plus{background:#d34836}
					.social-profile .fa:hover,.social-profile .fa:active{color:#FFF;-webkit-box-shadow:1px 1px 3px #333;-moz-box-shadow:1px 1px 3px #333;box-shadow:1px 1px 3px #333}
					</style>
					<div class='social-profiles-widget'>
					<ul class='social-profile circle'>
					<li><a href='https://www.facebook.com/smkyajdepokofficial/'><i class='fa fa-facebook'/></i></a></li>
					<!--<li><a href='#'><i class='fa fa-twitter'/></i></a></li>-->
					<li><a href='https://www.youtube.com/channel/UCmYQhAAew4lHcAOqhDitDQQ'><i class='fa fa-youtube'/></i></a></li>
					<!---<li><a href='#'><i class='fa fa-google-plus'/></i></a></li>-->
					<li><a href='https://www.instagram.com/smkyaj_official/'><i class='fa fa-instagram'/></i></a></li>
					</ul>
					</div>
					<?= $kontak['kontak'] ?>
                    <div id="googleMap" style="width:100%;height:500px;"></div>
				</div>
			</div>
			<?php require_once 'sidebar.php'; ?>
		</div>
		<?php require 'footer.php';?>