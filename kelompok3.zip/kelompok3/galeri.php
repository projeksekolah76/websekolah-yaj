<?php 

require_once 'koneksi.php';

$query = mysqli_query($koneksi, "SELECT * FROM tbl_galeri order by id desc ");
$galeri = mysqli_fetch_assoc($query);
$aktif = 'galeri'; 
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>galeri - SMK YAJ Depok</title>
	<link rel="stylesheet" href="resources/fonts/stylesheet.css">
	<link rel="stylesheet" href="resources/css/bootstrap.min.css">
	<link rel="stylesheet" href="resources/css/style.css">
	<link rel="icon" href="resources/images/logobc.png">
	
</head>
<body>
	<div class="container bg-light">
		<!-- top bar -->
		<?php require_once 'top-bar.php'?>
		<!-- nav bar -->
		<?php require_once 'navbar.php'; ?>

		<!-- content -->
		<div class="row p-3">
			<div class="col-md-8">
				<div class="title mb-3">
					Galeri SMK YAJ Depok
				</div>
				<?php $id = 1; ?>
				<?php while($galeri = mysqli_fetch_assoc($query)) : ?>
				<div class="artikel">
				<a rel="example_group" href="images/galeri/<?= $galeri['nama_file'] ?>"><img alt="example1" src="images/galeri/<?= $galeri['nama_file'] ?>" width="30%" class="float-left mb-3 img-thumbnail"/></a>
                

				
                
					
				</div>
				<?php $id++; ?>
				<?php endwhile; ?>
				
			</div>
			<?php require_once 'sidebar.php'; ?>
		</div>
		<?php require 'footer.php';?>