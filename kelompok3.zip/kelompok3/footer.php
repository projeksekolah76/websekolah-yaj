
		<div class="text-white footer">
			2021 © Copyright by <b><em>XI-RPL Kelompok 3</em></b>.
		</div>
	</div>

	<script src="resources/js/jquery.js"></script>
	<script src="resources/js/bootstrap.min.js"></script>
	<script src="resources/datatables/datatables.min.js"></script>
	<script src="resources/datatables/datatable.js"></script>
	<script src="slick-bg.js"></script>
	<script>
$(document).ready(function(){
  $('.ct-slick-homepage').slick({
  });
});
</script>
</body>
</html>